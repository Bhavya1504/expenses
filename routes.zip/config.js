// config.js
module.exports = {
    jwtSecret: 'bhavya', // Replace 'your_jwt_secret_here' with your actual JWT secret key.
  };
  