const express = require('express');
const cors = require('cors');
const userRoutes = require('./routes/user');
const expenseRoutes = require('./routes/expense'); // Include the expense routes
const { sequelize } = require('./util/database');
const userController = require('./controller/user');


const app = express();

// Allow requests from any origin
app.use(cors());

// Serve static files from the "Signup" folder
app.use('/Signup', express.static('Signup'));
app.use('/Login',express.static('Login'));
// Other middleware and route handlers
app.use(express.json());

// Define the POST route for login
app.post('/user/login', userController.login);

// Define the POST route for signup
app.post('/user/signup', userController.signup);

// Include the expense routes
app.use('/expense', expenseRoutes);


// Catch-all route for 404 errors
app.get('*', (req, res) => {
  res.status(404).send('Page not found');
});

// Set up the database connection using Sequelize
sequelize
  .sync()
  .then(() => {
    console.log('Database connection established successfully.');
    app.listen(3000, () => {
      console.log('Server is running on port 3000');
    });
  })
  .catch((error) => {
    console.error('Error syncing models:', error.stack);
  });
