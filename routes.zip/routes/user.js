const express = require('express');
const userController = require('../controller/user');
const router = express.Router();

// Define the POST route for signup
router.post('/signup', userController.signup);
router.post('/login',userController.login);

module.exports = router;


