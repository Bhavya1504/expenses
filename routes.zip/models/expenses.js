const { DataTypes, Sequelize } = require('sequelize'); // Import Sequelize from the sequelize instance

const { sequelize } = require('../util/database');

const Expense = sequelize.define('expenses', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true
    },
    expenseamount: DataTypes.INTEGER,
    category: DataTypes.STRING,
    description: DataTypes.STRING,
});

module.exports = Expense;
