
const generatedToken = ''; // Replace this with your actual generated token

// Store the token in the local storage
localStorage.setItem('jwtToken', generatedToken);

const API_BASE_URL = 'http://localhost:3000';

// Function to get the JWT token from local storage
function getToken() {
  return  localStorage.getItem('jwtToken');
}
// Axios request interceptor to add the Authorization header to each request
axios.interceptors.request.use(
  (config) => {
    const token = getToken();
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);
async function login(credentials) {
  try {
    const response = await axios.post(`${API_BASE_URL}/login`, credentials);
    const token = response.data.token;

    // Store the token in local storage
    localStorage.setItem('jwtToken', token);
    return token;
  } catch (error) {
    console.error('Error logging in:', error);
    return null;
  }
}

// Call the login function with user credentials to receive the token
const credentials = {
  username: 'radha@gmail.com',
  password: 'radha',
};
const token = login(credentials);
// Function to fetch and render expenses
async function fetchAndRenderExpenses() {
  try {
    const response = await axios.get(`${API_BASE_URL}/expense/getexpenses`);
    const expenses = response.data.expenses;
    renderExpenseList(expenses);
  } catch (error) {
    console.error('Error fetching expenses from the server:', error);
  }
}

// Function to add an expense to the server and then fetch and render expenses
async function addExpenseToServer(newExpense) {
  try {
    // Send a POST request to the server to add the expense
    await axios.post(`${API_BASE_URL}/expense/addexpense`, newExpense);
    console.log('Expense added successfully to the server');

    // Fetch and render updated expenses after adding a new expense
    fetchAndRenderExpenses();
  } catch (error) {
    console.error('Error adding expense to the server:', error);
  }
}

// Rest of your code...
// Event listener for form submission to add a new expense
document.getElementById('expenseForm').addEventListener('submit', (event) => {
  event.preventDefault();

  // Get the values from the form fields
  const amount = event.target.elements.expenseamount.value;
  const description = event.target.elements.description.value;
  const category = event.target.elements.category.value;

  // Create the newExpense object with the required properties
  const newExpense = {
    expenseamount: amount,
    description: description,
    category: category,
  };

  // Add the new expense to the server and then fetch and render expenses
  addExpenseToServer(newExpense);

  // Clear the form fields after submission
  event.target.elements.expenseamount.value = '';
  event.target.elements.description.value = '';
  event.target.elements.category.value = '';
});

// Function to display expenses on the UI
function renderExpenseList(expenses) {
  const expenseList = document.getElementById('expenseList');
  expenseList.innerHTML = '';

  expenses.forEach((expense) => {
    const expenseItem = document.createElement('li');
    expenseItem.textContent = `Amount: ${expense.expenseamount}, Description: ${expense.description}, Category: ${expense.category}`;
    expenseList.appendChild(expenseItem);
  });
}

// Fetch and render expenses on page load
fetchAndRenderExpenses();
