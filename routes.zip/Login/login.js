// login.js

async function login(e) {
    try {
        e.preventDefault();
        console.log(e.target.email.value);

        const loginDetails = {
            email: e.target.email.value,
            password: e.target.password.value
        }

        const response = await axios.post("http://localhost:3000/user/login", loginDetails);

        if (response.status === 200) {
            console.log(response.data.message); // 'Login successful'
            alert('Successfully logged in!'); // Display success message

            // Redirect to the Expense Tracker app after successful login
            window.location.href = "../ExpenseTracker/index.html";
        } else {
            throw new Error(response.data.message);
        }
    } catch (err) {
        console.error(err.message); // Display error message in the console
        alert('Check your credentials and try again.'); // Display error message to the user
    }
}

// Add event listener to the login form
document.getElementById('loginForm').addEventListener('submit', login);
